#include <stdio.h>
#include <conio.h>

int main()
{
    int n,d;
    scanf("%d",&n);
    d = n/4;
    printf("%d",(n-d)*249);
}
