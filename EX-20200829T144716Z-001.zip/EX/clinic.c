#include <stdio.h>
#include <stdlib.h>

int main()
{
    int t,a,b,i;

    scanf("%d %d %d",&n,&a,&b);


}
