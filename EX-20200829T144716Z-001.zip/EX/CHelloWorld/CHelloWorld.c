#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    int n;
    scanf("%d",&n);
    for(i=0;i<n;i++)
        printf("Hello World\n");
}
